# -*- coding: utf-8 -*-
"""
Created on Sun Nov  2 23:05:50 2014

@author: Eric Liao
"""

def approx_Pattern_Count(dna, pattern, d):
    count = 0
    Hamming_dis = 0
    for i in range(len(dna)-len(pattern)+1):
        pattern_2 = dna[i: i+len(pattern)]
        break
    for p1, p2 in zip(pattern, pattern_2):
            if p1 != p2:
                Hamming_dis += 1
                break
    if Hamming_dis <= d:
        count += 1
                    
    return count
    